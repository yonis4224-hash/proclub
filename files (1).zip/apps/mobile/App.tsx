import React, { useEffect, useState } from 'react';
import { Text, View, StyleSheet, ActivityIndicator } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import axios from 'axios';
import { API_BASE } from './src/config';

export default function App() {
  const [loading, setLoading] = useState(true);
  const [resp, setResp] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchPing() {
      try {
        const r = await axios.get(`${API_BASE}/`);
        setResp(r.data);
      } catch (e: any) {
        setError(e.message || 'خطأ في الاتصال');
      } finally {
        setLoading(false);
      }
    }
    fetchPing();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>ProClub (Expo)</Text>
      {loading ? <ActivityIndicator size="large" /> : null}
      {error ? <Text style={{ color: 'red' }}>خطأ: {error}</Text> : null}
      {resp ? (
        <View style={{ marginTop: 12 }}>
          <Text>استجابة من الـ API:</Text>
          <Text>{JSON.stringify(resp, null, 2)}</Text>
        </View>
      ) : null}
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16
  },
  title: { fontSize: 24, fontWeight: '700', marginBottom: 8 }
});