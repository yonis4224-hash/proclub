import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'تطبيقي الأول',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<String> items = [];

  final TextEditingController ctrl = TextEditingController();

  void addItem() {
    final text = ctrl.text.trim();
    if (text.isEmpty) return;
    setState(() {
      items.add(text);
      ctrl.clear();
    });
  }

  void removeItem(int i) {
    setState(() => items.removeAt(i));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('قائمة مهام بسيطة')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          children: [
            Row(children: [
              Expanded(
                child: TextField(controller: ctrl, decoration: InputDecoration(hintText: 'اكتب مهمة')),
              ),
              SizedBox(width: 8),
              ElevatedButton(onPressed: addItem, child: Text('إضافة')),
            ]),
            SizedBox(height: 12),
            Expanded(
              child: items.isEmpty
                  ? Center(child: Text('لا توجد مهام بعد'))
                  : ListView.builder(
                      itemCount: items.length,
                      itemBuilder: (_, i) => ListTile(
                        title: Text(items[i]),
                        trailing: IconButton(
                          icon: Icon(Icons.delete),
                          onPressed: () => removeItem(i),
                        ),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}